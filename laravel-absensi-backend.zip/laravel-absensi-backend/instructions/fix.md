dibagian attendances, List berisi data absensi karyawan, dengan kolom:
- User (nama karyawan)
- Date (tanggal absensi)
- Check In (jam check in)
- Check Out (jam check out)
- Status (On Time, Late, Absent)
- Total Hours (total jam kerja hari itu)
- Shift (nama shift hari itu)

Filter:
- Tanggal (range tanggal)
- User (pilih karyawan)
- Status (On Time, Late, Absent)
- Shift (pilih shift)

Actions:
- Export ke CSV/PDF

new attendance dihapus, karena absensi otomatis dari mobile app.
buatkan data dummy 20 data testing dan eksekusi sehingga bisa dicek di filament.
