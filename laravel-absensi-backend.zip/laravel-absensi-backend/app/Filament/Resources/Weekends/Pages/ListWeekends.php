<?php

namespace App\Filament\Resources\Weekends\Pages;

use App\Filament\Resources\Weekends\WeekendResource;
use Filament\Resources\Pages\ListRecords;

class ListWeekends extends ListRecords
{
    protected static string $resource = WeekendResource::class;
}
